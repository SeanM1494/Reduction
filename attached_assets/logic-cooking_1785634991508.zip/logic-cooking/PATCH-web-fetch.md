# Wiring the Claude-side fetch into the URL path

Two edits to `server/routes/recipes.ts`.

## 1. Add the import

```ts
import { structureRecipeFromUrl } from "../lib/fetchViaClaude";
```

## 2. Replace the body of the URL branch

Find the block that starts `const src = await fetchSource(url);` and replace
everything from there down to `cache.set(key, { recipe, at: Date.now() });`
with this:

```ts
      let recipe;
      let attempts = 1;
      let repaired: string[] = [];
      let via: "self" | "claude" = "self";

      try {
        // Our own fetch is cheaper and gives us JSON-LD when the site has it.
        const src = await fetchSource(url);
        const out = await structureRecipe({
          title: src.title,
          yieldText: src.yieldText,
          ingredients: src.ingredients,
          instructions: src.instructions,
          text: src.quality === "text" ? src.text : undefined,
          sourceUrl: url,
        });
        recipe = out.recipe;
        attempts = out.attempts;
        repaired = out.repaired;
        recipe.source = src.siteName;
      } catch (selfErr) {
        // Blocked, JS-rendered, or unreadable. Let Claude fetch it instead —
        // the request comes from Anthropic's infrastructure, not this Repl.
        console.warn("[extract] self-fetch failed, using web_fetch:", (selfErr as Error).message);
        const out = await structureRecipeFromUrl(url);
        recipe = out.recipe;
        attempts = out.attempts;
        repaired = out.repaired;
        via = "claude";
      }

      cache.set(key, { recipe, at: Date.now() });
```

Then add `via` to the response meta so you can see which path ran:

```ts
      return res.json({
        recipe,
        meta: { cached: false, source: "url", via, attempts, repaired },
      });
```

## 3. Same key guard in structureRecipe.ts

`new Anthropic()` at module scope throws at import time when the key is
missing, which takes down the whole server including `/api/health`. Replace
the top-level client:

```ts
let _client: Anthropic | null = null;
function getClient(): Anthropic {
  if (!process.env.ANTHROPIC_API_KEY)
    throw new Error("ANTHROPIC_API_KEY is not set. Add it in the Secrets tab.");
  if (!_client) _client = new Anthropic();
  return _client;
}
```

and change `client.messages.create` to `getClient().messages.create`.

## Checking it worked

Watch the console. A blocked site now logs:

```
[extract] self-fetch failed, using web_fetch: That site refused the request...
```

and still returns a diagram. `meta.via` tells you which path produced it —
`"self"` means your fetch worked, `"claude"` means the fallback ran.

## If the model rejects the tool

If you get an error about `web_fetch_20250910` being unsupported, the model
in `fetchViaClaude.ts` doesn't have the tool enabled. Change `MODEL` to
`claude-opus-4-6` and retry. The tool version and beta header stay the same.
